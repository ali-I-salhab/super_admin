import 'package:flutter/material.dart';

class Unknown extends StatelessWidget {
  const Unknown({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("unknowroute"),
    );
  }
}
