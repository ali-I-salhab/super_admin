import 'package:get/get.dart';

class AmentiesController extends GetxController {
  String pageswitcherstatus = 'icons';
}
